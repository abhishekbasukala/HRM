package com.hrm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hrm.domain.Employee;
import com.hrm.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value="/")
	public String homePage(){
		return "homePage";
	}
	
	@RequestMapping(value="/addEmployee", method=RequestMethod.POST)
	public String saveEmployee(Employee employee){
	
		employeeService.saveEmployee(employee);
		return "redirect:/homePage";
		
	}

}
