package com.hrm.domain;

public enum Designation {
	
	SUPERVISOR, DIRECTOR, HR, DEVELOPER, DESIGNER

}
